// Kamil Wolbach (280161)

// Exercise 1 — Hello World
// Write a program that prints text: Hello World!

public class JAVA_01_01 {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

// Public class (accessible to the JVM)
// Static method (accessible to the class)
// void, because the method does not return anything
// main, the name of the method, it accepts an array of strings as a parameter
// System.out.println, the method to print text to the console (new line)